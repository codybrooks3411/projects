Title:
DBClient Application - Software 2


Purpose:
This is a scheduling application of appointments for customers.
Also, included are 3 reports involving appointments by type and month,
as well as a contact schedule and tracking user activity.


Author:
Cody Brooks - email: cbr1128@wgu.edu
application version #1
12/29/22


IDE:
IntelliJ IDEA Community Edition 2021.3.1 is used for this project,
along with JDK 17.0.2 and JavaFX 11.0.2.


Running Project:
Once the program is running, the user is prompted to log-on via a login screen. After the user has logged on successfully,
options are presented to the user regarding viewing Customers, Appointments, and reports.


Additional report:
The third report displayed in the project is a report that shows customers and the countries that the customers are
located in.



SQL used:
The SQL connector used is mysql-connector-java-8.0.25











