package model;
/**This is the country class.*/
public class Country {

    private int countryID;
    private String country;

    public Country(int countryID, String country) {
        this.countryID = countryID;
        this.country = country;
    }

    public Country(int countryID) {
        this.countryID = countryID;
    }
    /**This is the get country ID method. This method gets the country ID.*/
    public int getCountryID() {
        return countryID;
    }

    public void setCountryID(int countryID) {
        this.countryID = countryID;
    }
    /**This is the get country method. This method gets the country.*/
    public String getCountry() {
        return country;
    }

    /**This is the set country method. This method sets the country.*/
    public void setCountry(String country) {
        this.country = country;
    }

    @Override
    public String toString() {
        return countryID + " - " + country;
    }
}
