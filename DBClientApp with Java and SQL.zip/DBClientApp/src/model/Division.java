package model;
/**This is the division class.*/
public class Division {

    private String division;
    private int divisionID, countryID;

    public Division(String division, int divisionID, int countryID) {
        this.division = division;
        this.divisionID = divisionID;
        this.countryID = countryID;
    }

    public Division(int divisionID) {
        this.divisionID = divisionID;
    }
    /**This is the get division method. This method gets the division.*/
    public String getDivision() {
        return division;
    }

    public void setDivision(String division) {
        this.division = division;
    }
    /**This is the get division ID method. This method gets the division ID.*/
    public int getDivisionID() {
        return divisionID;
    }

    public void setDivisionID(int divisionID) {
        this.divisionID = divisionID;
    }

    public int getCountryID() {
        return countryID;
    }

    public void setCountryID(int countryID) {
        this.countryID = countryID;
    }

    @Override
    public String toString() {
        return divisionID + " - " + division;
    }

}
