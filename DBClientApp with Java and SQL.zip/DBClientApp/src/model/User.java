package model;
/**This is the user class.*/
public class User {

    private int userID;
    private String userName, password;
    public static String currentUser;

    public User(int userID, String userName, String password) {
        this.userID = userID;
        this.userName = userName;
        this.password = password;
    }
    /**This is the get user ID method. This method gets the user ID.*/
    public int getUserID() {
        return userID;
    }

    public void setUserID(int userID) {
        this.userID = userID;
    }
    /**This is the get username method. This method gets the username.*/
    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }
    /**This is the get password method. This method gets the password.*/
    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Override
    public String toString() {
        return String.valueOf(userID);
    }
}