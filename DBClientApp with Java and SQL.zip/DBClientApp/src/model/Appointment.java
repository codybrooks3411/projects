package model;

import helper.JDBC;
import helper.ListManager;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
/**This is the Appointment class.*/
public class Appointment {


    private String title, description, location, Type;
    private LocalDateTime start, end;
    private int appointmentID, customerID, userID, contactId;

    public Appointment(String title, String description, String location, String type, LocalDateTime start,
                       LocalDateTime end, int appointmentID, int customerID, int userID, int contactId) {
        this.title = title;
        this.description = description;
        this.location = location;
        Type = type;
        this.start = start;
        this.end = end;
        this.appointmentID = appointmentID;
        this.customerID = customerID;
        this.userID = userID;
        this.contactId = contactId;
    }
    /**This is the get title method. This method gets the title.*/
    public String getTitle() {
        return title;
    }
    /**This is the set title method. This method sets the title.*/
    public void setTitle(String title) {
        this.title = title;
    }
    /**This is the get description method. This method gets the description.*/
    public String getDescription() {
        return description;
    }
    /**This is the set description method. This method sets the description.*/
    public void setDescription(String description) {
        this.description = description;
    }
    /**This is the get location method. This method gets the location.*/
    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }
    /**This is the get type method. This method gets the type.*/
    public String getType() {
        return Type;
    }
    /**This is the set type method. This method sets the type.*/
    public void setType(String type) {
        Type = type;
    }
    /**This is the get start method. This method gets the start times.*/
    public LocalDateTime getStart() {
        return start;
    }

    /**This is the set start method. This method sets the start times.*/
    public void setStart(LocalDateTime start) {
        this.start = start;
    }
    /**This is the get end method. This method gets the end times.*/
    public LocalDateTime getEnd() {
        return end;
    }
    /**This is the set end method. This method sets the end times.*/
    public void setEnd(LocalDateTime end) {
        this.end = end;
    }
    /**This is the get appointment ID method. This method gets the appointment ID.*/
    public int getAppointmentID() {
        return appointmentID;
    }

    public void setAppointmentID(int appointmentID) {
        this.appointmentID = appointmentID;
    }
    /**This is the get customer ID method. This method gets the customer ID.*/
    public int getCustomerID() {
        return customerID;
    }

    public void setCustomerID(int customerID) {
        this.customerID = customerID;
    }
    /**This is the get user ID method. This method gets the user ID.*/
    public int getUserID() {
        return userID;
    }

    public void setUserID(int userID) {
        this.userID = userID;
    }
    /**This is the get contact ID method. This method gets the contact ID.*/
    public int getContactId() {
        return contactId;
    }

    public void setContactId(int contactId) {
        this.contactId = contactId;
    }
}


