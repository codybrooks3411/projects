package model;

import helper.JDBC;
import helper.ListManager;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
/**This is the contact class.*/
public class Contact{

private String contactName, email;
private static int contactID;

    public Contact(String contactName, String email, int contactID) {
        this.contactName = contactName;
        this.email = email;
        this.contactID = contactID;
    }

    public String getContactName() {
        return contactName;
    }

    public void setContactName(String contactName) {
        this.contactName = contactName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
    /**This is the get contact ID method. This method gets the contact ID.*/
    public int getContactID() {
        return contactID;
    }

    public void setContactID(int contactID) {
        this.contactID = contactID;
    }

    @Override
    public String toString() {
        return contactName;
    }
}
