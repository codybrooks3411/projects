package model;

import utilities.CustomerCRUD;

import java.sql.SQLException;
/**This is the customer class.*/
public class Customer {

    public int customerID;
    public int countryID;
    private int divisionID;
    private String postalCode;
    private String customerName;
    private String address;
    private String phone;

    public Customer(int customerID, int countryID, int divisionID, String postalCode, String customerName,
                    String address, String phone) {
        this.customerID = customerID;
        this.countryID = countryID;
        this.divisionID = divisionID;
        this.postalCode = postalCode;
        this.customerName = customerName;
        this.address = address;
        this.phone = phone;
    }

    /**This is the get customer ID method. This method gets the customer ID.*/
    public int getCustomerID() {
        return customerID;
    }
    /**This is the get country ID method. This method gets the country ID.*/
    public int getCountryID() {
        return countryID;
    }

    public void setCustomerID(int customerID) {
        this.customerID = customerID;
    }

    public void setCountryID(int countryID) {
        this.countryID = countryID;
    }

    /**This is the get division ID method. This method gets the division ID.*/
    public int getDivisionID() {
        return divisionID;
    }

    public void setDivisionID(int divisionID) {
        this.divisionID = divisionID;
    }
    /**This is the get postal code method. This method gets the postal code.*/
    public String getPostalCode() {
        return postalCode;
    }

    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }
    /**This is the get customer name method. This method gets the customer name.*/
    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }
    /**This is the get address method. This method gets the address.*/
    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
    /**This is the get phone method. This method gets the phone number.*/
    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    @Override
    public String toString() {
        return String.valueOf(customerID);
    }


}









