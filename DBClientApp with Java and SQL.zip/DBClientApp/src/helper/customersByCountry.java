package helper;

/**This is the customers by country class.*/
public class customersByCountry {

    String name;
    int divisionId;
    String countryName;

    public customersByCountry(String name, int divisionId, String countryName) {
        this.name = name;
        this.divisionId = divisionId;
        this. countryName = countryName;

    }

    public String getCountryName() {
        return countryName;
    }

    /**This is the get name method. This method gets the name.*/
    public String getName() {
        return name;
    }

    /**This is the set name method. This method sets the name.*/
    public void setName(String name) {
        this.name = name;
    }

    public int getDivisionId() {
        return divisionId;
    }

    public void setDivisionId(int divisionId) {
        this.divisionId = divisionId;
    }
}
