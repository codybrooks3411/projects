package helper;

/**This is the getting appointments by month and type class.*/
public class gettingApptByMonthAndType {

    private String month;
    private String type;
    private int totalAppointments;

    public gettingApptByMonthAndType(String month, String type, int totalAppointments) {
        this.month = month;
        this.type = type;
        this.totalAppointments = totalAppointments;
    }

    /**This is the get month method. This method gets the month.*/
    public String getMonth() {
        return month;
    }

    /**This is the get type method. This method gets the type.*/
    public String getType() {
        return type;
    }

    /**This is the get total appointment's method. This method gets the total appointments.*/
    public int getTotalAppointments() {
        return totalAppointments;
    }
}
