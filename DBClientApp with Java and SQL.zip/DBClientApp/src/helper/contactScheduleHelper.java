package helper;

import controller.contactSchedule;

import java.time.LocalDateTime;

/**This is the contact schedule helper class.*/
public class contactScheduleHelper extends contactSchedule {

        private int contactId;
        private int appointmentId;
        private String title;
        private String type;
        private String description;
        private LocalDateTime start;
        private LocalDateTime end;
        private int customerId;

        public contactScheduleHelper(int contactId, int appointmentId, String title, String type, String description, LocalDateTime start, LocalDateTime end, int customerId) {
            this.contactId = contactId;
            this.appointmentId = appointmentId;
            this.title = title;
            this.type = type;
            this.description = description;
            this.start = start;
            this.end = end;
            this.customerId = customerId;
        }

        public int getContactId() {
            return contactId;
        }

        public int getAppointmentId() {
            return appointmentId;
        }

        /**This is the get title method. This method gets the title.*/
        public String getTitle() {
            return title;
        }

    /**This is the get type method. This method gets the type.*/
        public String getType() {
            return type;
        }

    /**This is the get description method. This method gets the description.*/
        public String getDescription() {
            return description;
        }

    /**This is the get start method. This method gets the start time.*/
        public LocalDateTime getStart() {
            return start;
        }

    /**This is the get end method. This method gets the end time.*/
        public LocalDateTime getEnd() {
            return end;
        }

    /**This is the get customer id method. This method gets the customer id.*/
        public int getCustomerId() {
            return customerId;
        }

    }
