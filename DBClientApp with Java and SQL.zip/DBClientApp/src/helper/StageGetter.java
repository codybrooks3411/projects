package helper;


import javafx.event.ActionEvent;
import javafx.stage.Stage;

/**This is the functional interface that corresponds with 1 of 2 lambdas used.*/
@FunctionalInterface
public interface StageGetter {

    Stage getStage(ActionEvent e);

}
