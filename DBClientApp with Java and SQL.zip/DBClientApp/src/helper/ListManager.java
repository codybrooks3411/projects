package helper;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.*;
import utilities.AppointmentCRUD;

import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.LocalTime;

/**This is the list manager class.*/
public abstract class ListManager {

    /**This is the all users method. This method creates a list of users.*/
    public static ObservableList<User> allUsers = FXCollections.observableArrayList();

    /**This is the start times method. This method creates a list of start times.*/
    public static ObservableList<LocalTime> startTimes = FXCollections.observableArrayList();

    /**This is the end times method. This method creates a list of end times.*/
    public static ObservableList<LocalTime> endTimes = FXCollections.observableArrayList();


    /**This is the all contacts method. This method creates a list of contacts.*/
    public static ObservableList<Contact> allContacts = FXCollections.observableArrayList();


    /**This is the all customer's method. This method creates a list of customers.*/
    public static ObservableList<Customer> allCustomers = FXCollections.observableArrayList();

    public static void updateCustomerList(int index, Customer customer) {

        allCustomers.set(index, customer);

    }

    /**This is the all appointment's method. This method creates a list of appointments.*/
    public static ObservableList<Appointment> allAppointments = FXCollections.observableArrayList();
   /* public static ObservableList<Appointment> getAllAppointments() throws SQLException {
        AppointmentCRUD.select();
        return allAppointments;
    }*/



    public static void updateAppointmentList(int index, Appointment appointment) {
        allAppointments.set(index, appointment);
    }

    /**This is the all countries' method. This method creates a list of countries.*/
    public static ObservableList<Country> allCountries = FXCollections.observableArrayList();

    /**This is the all divisions' method. This method creates a list of divisions.*/
    public static ObservableList<Division> allDivisions = FXCollections.observableArrayList();


    public static ObservableList<Division> addingDivisions = FXCollections.observableArrayList();







}
