package helper;

/**This is teh getting appointments by month class.*/
public class gettingApptsByMonth {

    private String month;


    public gettingApptsByMonth(String month) {
        this.month = month;
    }
    /**This is the get month method. This method gets the month.*/
    public String getMonth() {
        return month;
    }

}
