package helper;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.User;

import java.io.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.NoSuchElementException;
import java.util.Scanner;

import static java.time.ZoneOffset.UTC;

/**This is the user activity class.*/
public class UserActivity {

    private String date;
    private String time;
    private String userName;
    private Boolean successfullOrNot;

    public UserActivity(String date, String time, String userName, Boolean successfullOrNot) {
        this.date = date;
        this.time = time;
        this.userName = userName;
        this.successfullOrNot = successfullOrNot;
    }

    /**This is the get date method. This method gets the date.*/
    public String getDate() {
        return date;
    }

    /**This is the get time method. This method gets the time.*/
    public String getTime() {
        return time;
    }

    /**This is the get username method. This method gets the username.*/
    public String getUserName() {
        return userName;
    }

    /**This is the get successfull or not method. This method returns successfull or not.*/
    public Boolean getSuccessfullOrNot() {
        return successfullOrNot;
    }

    /**This is the user activity records method. This method creates a list of user activity data.*/
    public static ObservableList<UserActivity> userActivityRecords = FXCollections.observableArrayList();


    /**This is the get user activity records method. This method returns the user activity records list.*/
    public static ObservableList<UserActivity> getUserActivityRecords() {
        return userActivityRecords;
    }


    /**This is the successful or not method. This method captures if a user has successfully logged in or not
     * and adds the captured data to a file.*/
    public static boolean successfullOrNot(String user, String pass) throws IOException {
        for (User u : ListManager.allUsers) {
            User.currentUser = user;
            if (user.equals(u.getUserName())) {
                if (pass.equals(u.getPassword())) {



                    // reads from login_activity then adds into user activity report
                    Scanner read = new Scanner(new File("login_activity.txt"));
                    while (read.hasNextLine()) {
                        try {
                            String date = read.next();
                            String time = read.next();
                            String username = read.next();
                            Boolean successfullOrNot = Boolean.valueOf(read.next());
                            UserActivity record = new UserActivity(date, time, username, successfullOrNot);
                            userActivityRecords.add(record);
                        } catch (NoSuchElementException e) { }
                    }
                    read.close();
                    return true;
                }
            }
        }
        // writes to login_activity if invalid
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
        BufferedWriter writer = new BufferedWriter(new FileWriter("login_activity.txt", true));
        writer.write(LocalDateTime.now(UTC).format(dtf) + " | " + User.currentUser + " | invalid\n");
        writer.close();

        // reads from login_activity then adds into user activity report

        Scanner read = new Scanner(new File("login_activity.txt"));
        while (read.hasNextLine()) {
            try {
                String date = read.next();
                String time = read.next();
                String userName = read.next();
                Boolean successfullOrNot = Boolean.valueOf(read.next());
                UserActivity record = new UserActivity(date, time, userName, successfullOrNot);
                userActivityRecords.add(record);
            } catch (NoSuchElementException e) { }
        }
        read.close();
        return false;
    }
}


