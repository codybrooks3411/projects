package com.company;
import helper.JDBC;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import utilities.*;

import java.sql.SQLException;
import java.util.ResourceBundle;


public class JDBCProject extends Application {

    public static ResourceBundle rb;

    /**
     * this is the start method.
     *
     * @param primaryStage starts the program by displaying the main menu
     * @throws java.lang.Exception throws exception
     */

    @Override
    public void start(Stage primaryStage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("/view/Login.fxml"));
        Scene scene = new Scene(root);
        primaryStage.setScene(scene);
        primaryStage.show();

    }






    public static void main(String[] args) throws SQLException {


       // rb = ResourceBundle.getBundle("com.company/Nat", Locale.getDefault());

       // if(Locale.getDefault().getLanguage().equals("fr") || Locale.getDefault().getLanguage().equals("en") || Locale.getDefault().getLanguage().equals("fr"))
            //System.out.println(rb.getString("hello") + " " + Arrays.toString(rb.getStringArray("world")));


            // write your code here
            JDBC.openConnection();//connect to db



           AppointmentCRUD.select();
           ContactCRUD.select();
           CountryCRUD.select();
           DivisionCRUD.select();
           UserCRUD.select();

        launch(args);



         /*  int rowsAffected = CustomerCRUD.insert("Cody", "77 river", "37221", "615-476-7012", new Date(2022-7-7), "admin", new Timestamp(2022-7-8), "admin", 3);


        //check rows affected
         if(rowsAffected > 0)
          System.out.println(rowsAffected + " row(s) affected");
        else
          System.out.println("no change");*/


            //String selectStatement = "SELECT * FROM countries";

            //DBQuery.setPrepareStatement(connection, selectStatement); //create preparedStatement

           // PreparedStatement ps = DBQuery.getPreparedStatement();


            // String countryName, newCountry, createdBy;
            //String createDate = "2022-01-10 00:00:00";
            //String createdBy = "admin";
            //String lastUpdatedBy = "admin";


            //get keyboard input
            // Scanner keyboard = new Scanner(System.in);
            //System.out.print("enter a country to delete: ");
            //countryName = keyboard.nextLine();

            //System.out.print("enter new country: ");
            //newCountry = keyboard.nextLine();

            //System.out.print("enter user: ");
            //createdBy = keyboard.nextLine();



            /*ps.execute();//execute preparedStatement

            ResultSet rs = ps.getResultSet();

            //forward scroll resultset
            while (rs.next()) {
                int Country_ID = rs.getInt("Country_ID");
                String countryName = rs.getString("Country");
                LocalDate date = rs.getDate("Create_Date").toLocalDate();
                LocalTime time = rs.getTime("Create_Date").toLocalTime();
                String createdBy = rs.getString("Created_By");
                //***** LocalDateTime lastUpdate = rs.getTimestamp("Last_Update").toLocalDateTime();*** system does not like
                //****also wont delete and adding a duplicate row when adding****

                //display record
                System.out.println(Country_ID + " | " + countryName + " | " + date + " " + time + " | " + createdBy);

            }*/


            //check rows affected
            // if(ps.getUpdateCount() > 0)
            //   System.out.println(ps.getUpdateCount() + " row(s) affected");
            //else
            //  System.out.println("no change");




      /*  DBQuery.setStatement(connection); //create statement object
        Statement statement = DBQuery.getStatement(); //get statement reference

        String countries, Create_Date, Created_By, Last_Updated_By;
        Scanner keyboard = new Scanner(System.in);
        System.out.print("Enter a country: ");
        countries = keyboard.nextLine();
        Create_Date = "2022-01-09 00:00:00";
        Created_By = "admin";
        Last_Updated_By = "admin";

        if(countries.contains("'"))
            countries = countries.replace("'", "\\'");




        //raw sql insert statement
        //String insertStatement = "INSERT INTO countries(country, Create_Date, Created_By, Last_Updated_By) VALUES('US', '2022-01-08 00:00:00', 'admin', 'admin')";
        String insertStatement = "INSERT INTO countries(country, Create_Date, Created_By, Last_Updated_By)" +
                "VALUES(" +
                "'" + countries + "'," +
                "'" + Create_Date + "'," +
                "'" + Created_By + "'," +
                "'" + Last_Updated_By + "'" +
                ")";
        //variable insert
       // String countryName = "Canada";
        //String createDate = "2022-01-08 00:00:00";
        //String createdBy = "admin";
        //String lastUpdatedBy = "admin";

        String insertStatement = "INSERT INTO countries(country, Create_Date, Created_By, Last_Updated_By)" +
                                    "VALUES(" +
                                    "'" + countryName +"'," +
                                    "'" + createDate +"'," +
                                    "'" + createdBy +"'," +
                                    "'" + lastUpdatedBy +"'" +
                                    ")";


        //update statement
       // String updateStatement = "UPDATE countries SET country = 'Japan' WHERE country = 'Canada'";
        //delete statement
        //String deleteStatement = "DELETE FROM countries WHERE country = 'Japan'";
        //execute sql statement
        statement.execute(insertStatement);

        //confirm rows affected
        if(statement.getUpdateCount() > 0)
            System.out.println(statement.getUpdateCount() + " row(s) affected");
        else
            System.out.println("No change");


        //String insertStatement = "SELECT * FROM countries WHERE " + country;//select statement
        try{
            statement.execute(insertStatement);//execute statement

            if(statement.getUpdateCount() > 0)
                System.out.println(statement.getUpdateCount() + " row(s) affected");
            else
                System.out.println("No change");

            //ResultSet rs = statement.getResultSet();

            // forward scroll resultset
             while(rs.next())
            {
                int Country_ID = rs.getInt("Country_ID");
                String countryName = rs.getString("country");
                LocalDate date = rs.getDate("Create_Date").toLocalDate();
                LocalTime time = rs.getTime("Create_Date").toLocalTime();
                String createdBy = rs.getString("Created_By");
                LocalDateTime lastUpdate = rs.getTimestamp("Last_Update").toLocalDateTime();

                //display record
                System.out.println(Country_ID + " | " + countryName + " | " + date + " " + time + " | " + createdBy);

            }
    }
        catch(Exception e)
        {
          System.out.println(e.getMessage());
        }*/


            JDBC.closeConnection();
        }





}



