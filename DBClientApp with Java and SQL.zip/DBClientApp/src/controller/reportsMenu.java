package controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

import java.io.IOException;

/**This is the report's menu class.*/
public class reportsMenu {

    Stage stage;
    Parent scene;

    @FXML
    private Button exit;

    /**This is the exit button method. This method switches screens to the customer menu page.*/
    @FXML
    void onActionExit(ActionEvent event) throws IOException {

        stage = (Stage)((Button)event.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/view/customerMenu.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();

    }

    /**This is the appointments by type and month button method. This method switches screens to the
     * appointments by type and month page.*/
    public void onActionApptsByTypeAndMonth(ActionEvent event) throws IOException {

        stage = (Stage)((Button)event.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/view/apptsByTypeAndMonth.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();
    }

    /**This is the contact schedule button method. This method switches screens to the contact schedule page.*/
    public void onActionContactSchedule(ActionEvent event) throws IOException {

        stage = (Stage)((Button)event.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/view/contactSchedule.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();
    }

    /**This is the customers by country button method. This method switches screens to the customers
     * by country page.*/
    public void onActionCustomersByCountry(ActionEvent event) throws IOException {
        stage = (Stage)((Button)event.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/view/customersByCountryView.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();
    }
}
