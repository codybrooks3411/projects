package controller;

import helper.ListManager;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import model.Appointment;
import model.Customer;
import utilities.AppointmentCRUD;
import utilities.CustomerCRUD;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.time.*;
import java.util.Optional;
import java.util.ResourceBundle;

import helper.ListManager;

/**This is the customer menu class.*/
public class customerMenu implements Initializable {

    public Button reportsBtn;
    public Button userActivityBtn;
    Stage stage;
    Parent scene;


    @FXML
    private TableView<Customer> customersTable;

    @FXML
    private TableColumn<Customer, Integer> customerIdCol;

    @FXML
    private TableColumn<Customer, String> NameCol;

    @FXML
    private TableColumn<Customer, String> phoneCol;

    @FXML
    private TableColumn<Customer, String> AddressCol;

    @FXML
    private TableColumn<Customer, String> zipCol;

    @FXML
    private TableColumn<Customer, Integer> FLDCol;

    @FXML
    private TableColumn<Customer, String> countryCol;


    @FXML
    private Button exit;

    @FXML
    private Button reportsButton;

    @FXML
    private TableView<Appointment> appointmentsTable;

    @FXML
    private TableColumn<Appointment, Integer> appointmentIdCol;

    @FXML
    private TableColumn<Appointment, String> titleCol;

    @FXML
    private TableColumn<Appointment, String> descriptionCol;

    @FXML
    private TableColumn<Appointment, String> locationCol;

    @FXML
    private TableColumn<Appointment, String> contactCol;

    @FXML
    private TableColumn<Appointment, String> typeCol;

    @FXML
    private TableColumn<Appointment, String> startDateTimeCol;

    @FXML
    private TableColumn<Appointment, String> endDateTimeCol;

    @FXML
    private TableColumn<Appointment, Integer> customerId2Col;

    @FXML
    private TableColumn<Appointment, Integer> userIdCol;



    @FXML
    private Text customersTxt;

    @FXML
    private Text appointmentsTxt;

    @FXML
    private Button addCustomer;

    @FXML
    private Button updateCustomer;

    @FXML
    private Button deleteCustomer;

    @FXML
    private Button makeAppointment;

    @FXML
    private Button updateAppointmentBtn;

    @FXML
    private Button deleteAppointmentBtn;

    @FXML
    private RadioButton byWeekRb;

    @FXML
    private RadioButton byMonthRb;


   /* @FXML
    void onActionApptByMonth(ActionEvent event) {

    }

    @FXML
    void onActionApptByWeek(ActionEvent event) {

    }*/



    /**This is the appointments by month radio button method. This method populates the table with data
     * when clicked.*/
    @FXML
    public ObservableList<Appointment> onActionApptByMonth(ActionEvent event) {

        Month currentMonth = LocalDateTime.now().getMonth();
        LocalDateTime start = LocalDateTime.of(LocalDate.now().getYear(), currentMonth,
                1, 0, 0);
        LocalDateTime end = start.plusMonths(1);
        ObservableList<Appointment> viewCurrentMonth = ListManager.allAppointments.filtered(a -> {

            if (a.getStart().isAfter(start) && a.getStart().isBefore(end) ) {

                return true;


            }
            return false;

        });

        appointmentsTable.setItems(viewCurrentMonth);
        return viewCurrentMonth;
    }


    /**This is the appointments by week radio button method. This method populates the table with data
     * when clicked*/
    @FXML
    public ObservableList<Appointment> onActionApptByWeek(ActionEvent event) {

        LocalDateTime today = LocalDateTime.of(LocalDate.now(), LocalTime.of(0,0));
        LocalDateTime start = today.minusDays(today.getDayOfWeek().getValue());
        LocalDateTime end = start.plusDays(7);

        ObservableList<Appointment> currentWeek = ListManager.allAppointments.filtered(a -> {

            if (a.getStart().isAfter(start) && a.getStart().isBefore(end)) {

                return true;

            }
            return false;

        });
        appointmentsTable.setItems(currentWeek);
        return currentWeek;
    }



    /**This is the delete appointments method. This method deletes appointments.*/
    @FXML
    void onActionDeleteAppointment(ActionEvent event) throws SQLException, IOException {
        Appointment app = appointmentsTable.getSelectionModel().getSelectedItem();
        if(app == null) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION, "No appt selected pls select appt");
            alert.showAndWait();
            return;
        }

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "Are you sure you want to delete appt " +
                "Id:"+app.getAppointmentID()+" and type:"+app.getType()+"?");

        Optional<ButtonType> result = alert.showAndWait();

        if(result.isPresent() && result.get() == ButtonType.OK)
        {



            AppointmentCRUD.delete(app.getAppointmentID());

            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("/view/customerMenu.fxml"));
            loader.load();


        }

    }

    /**This is the update appointments method. This method populates the page with data that can updated.*/
    @FXML
    void onActionUpdateAppointment(ActionEvent event) throws IOException {

        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("/view/updatingAppointments.fxml"));
        loader.load();

        updatingAppointments uc = loader.getController();
        uc.sendAppointment(appointmentsTable.getSelectionModel().getSelectedItem(),
                appointmentsTable.getSelectionModel().getSelectedIndex());



        stage = (Stage)((Button)event.getSource()).getScene().getWindow();
        Parent scene = loader.getRoot();
        stage.setScene(new Scene(scene));
        stage.show();

       /* stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/view/updatingAppointments.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();*/

    }


    /**This is the add customer button method. This method switches screens to the adding customers page.*/
    @FXML
    void onActionAddCustomer(ActionEvent event) throws IOException {

        stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/view/addingCustomers.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();

    }

    /**This is the make appointment button method. This method switches screens to the adding appointments page.*/
    @FXML
    void onActionMakeAppointment(ActionEvent event) throws IOException {

        stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/view/addingAppointments.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();

    }


    /**This is the delete customer method. This method deletes a customer.*/
    @FXML
    void onActionDeleteCustomer(ActionEvent event) throws SQLException, IOException {

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "This will delete, do you want to continue?");

        Optional<ButtonType> result = alert.showAndWait();

        if(result.isPresent() && result.get() == ButtonType.OK)
        {

            Customer customer = customersTable.getSelectionModel().getSelectedItem();

           // AppointmentCRUD.delete(customer.getCustomerID());
            CustomerCRUD.delete(customer.getCustomerID());

            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("/view/customerMenu.fxml"));
            loader.load();


        }


    }


    /**This is the exit button method. This method switches screens to the login page.*/
    @FXML
    void onActionExit(ActionEvent event) throws IOException {

        stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/view/Login.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();

    }


    /**This is the update customer method. This method populates the page with data that can be updated.*/
    @FXML
    void onActionUpdateCustomer(ActionEvent event) throws IOException, SQLException {

        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("/view/updatingCustomers.fxml"));
        loader.load();

        updatingCustomers uc = loader.getController();
        uc.sendCustomer(customersTable.getSelectionModel().getSelectedItem(),
                customersTable.getSelectionModel().getSelectedIndex());


        stage = (Stage)((Button)event.getSource()).getScene().getWindow();
        Parent scene = loader.getRoot();
        stage.setScene(new Scene(scene));
        stage.show();


       /* stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/view/updatingCustomers.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();*/

    }


    /**This is the initialize method. This method initializes the customer and appointments tables.*/
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        try {
            CustomerCRUD.select();
        } catch (SQLException e) {
            e.printStackTrace();        }


        customersTable.setItems(ListManager.allCustomers);
        customerIdCol.setCellValueFactory(new PropertyValueFactory<>("customerID"));
        NameCol.setCellValueFactory(new PropertyValueFactory<>("customerName"));
        AddressCol.setCellValueFactory(new PropertyValueFactory<>("address"));
        zipCol.setCellValueFactory(new PropertyValueFactory<>("postalCode"));
        FLDCol.setCellValueFactory(new PropertyValueFactory<>("divisionID"));
        countryCol.setCellValueFactory(new PropertyValueFactory<>("countryID"));
        phoneCol.setCellValueFactory(new PropertyValueFactory<>("phone"));
        customersTable.getSelectionModel().select(selectCustomer(1));

        try {
            AppointmentCRUD.select();
        } catch (SQLException e) {
            e.printStackTrace();
        }


        appointmentsTable.setItems(ListManager.allAppointments);
        appointmentIdCol.setCellValueFactory(new PropertyValueFactory<>("appointmentID"));
        titleCol.setCellValueFactory(new PropertyValueFactory<>("title"));
        descriptionCol.setCellValueFactory(new PropertyValueFactory<>("description"));
        locationCol.setCellValueFactory(new PropertyValueFactory<>("location"));
        contactCol.setCellValueFactory(new PropertyValueFactory<>("contactId"));
        typeCol.setCellValueFactory(new PropertyValueFactory<>("Type"));
        startDateTimeCol.setCellValueFactory(new PropertyValueFactory<>("start"));
        endDateTimeCol.setCellValueFactory(new PropertyValueFactory<>("end"));
        customerId2Col.setCellValueFactory(new PropertyValueFactory<>("customerID"));
        userIdCol.setCellValueFactory(new PropertyValueFactory<>("userID"));
        try {
            appointmentsTable.getSelectionModel().select(selectAppointment(1));
        } catch (SQLException e) {
            e.printStackTrace();
        }


    }

    public Customer selectCustomer(int CustomerId) {
        for (Customer allCustomer : ListManager.allCustomers) {

            if(allCustomer.getCustomerID() == CustomerId)
                return allCustomer;

        }
        return null;
    }

    public Appointment selectAppointment(int appointmentID) throws SQLException {
        for (Appointment allAppointments : ListManager.allAppointments) {

            if(allAppointments.getAppointmentID() == appointmentID)
                return allAppointments;

        }
        return null;
    }


    /**This is the reports button method. This method switches screens to the report's menu page.*/
    public void onActionReports(ActionEvent event) throws IOException {

        stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/view/reportsMenu.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();
    }


    /**This is the user activity button method. This method switches screens to the user activity page.*/
    public void onActionUserActivity(ActionEvent event) throws IOException {

        stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/view/userActivity.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();

    }

    /**This is the all appointments button method. This method populates the table with all appointment's data
     * when clicked.*/
    public void onActionAllAppts(ActionEvent actionEvent) throws SQLException {

        appointmentsTable.setItems(ListManager.allAppointments);

    }
}



