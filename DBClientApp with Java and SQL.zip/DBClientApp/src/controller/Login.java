package controller;

import com.company.JDBCProject;
import helper.ListManager;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import model.Appointment;
import model.User;
import utilities.AppointmentCRUD;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

import static helper.JDBC.connection;
import static helper.ListManager.allUsers;
import static java.time.ZoneOffset.UTC;

/**This is the login class.*/
public class Login implements Initializable {
    private ResourceBundle rb = ResourceBundle.getBundle("Nat", Locale.getDefault());
    @FXML
    private Label userNameLbl;
    @FXML
    private Label passwordLbl;
    Stage stage;
    Parent scene;


    @FXML
    private Button LoginTxt;

    @FXML
    private Button ExitTxt;

    @FXML
    private TextField userNameTxt;

    @FXML
    private PasswordField passwordTxt;

    @FXML
    private Label zoneIdLbl;


    /**This is the exit button method. This method exits the program.*/
    @FXML
    void OnActionExit(ActionEvent event) {
        System.exit(0);

    }

    /**This is the login button method. This method logs the user in and switches to the customer menu page
     * if successful.*/
    @FXML
    void OnActionLogin(ActionEvent event) throws IOException, SQLException {

        for (User users : allUsers) {


            if (userNameTxt.getText().equals(users.getUserName()) && passwordTxt.getText().equals(users.getPassword())) {

                // writes to login_activity if successful
                DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
                PrintWriter writer = new PrintWriter(new FileWriter("login_activity.txt", true));
                writer.append(LocalDateTime.now(UTC).format(dtf) + " | " + users.getUserName() + " | success\n");
                writer.flush();
                writer.close();



                // 15 minute appointment checker
                LocalDateTime currentTime = LocalDateTime.now();
                ZonedDateTime currentTimeZone = ZonedDateTime.now();
                DateTimeFormatter dtf2 = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");


                // initializing the upcoming Appointments list
                ObservableList<Appointment> upcomingAppointments = FXCollections.observableArrayList();

                for (Appointment a : ListManager.allAppointments) {
                    LocalDateTime convertStart = LocalDateTime.from(a.getStart().atZone(ZoneId.from(currentTimeZone)));

                    if (convertStart.minusMinutes(15).isBefore(currentTime) && convertStart.isAfter(currentTime)) {
                        upcomingAppointments.add(a);
                    }
                }

                if (upcomingAppointments.isEmpty()) {
                    Alert reminder = new Alert(Alert.AlertType.INFORMATION, "There are no upcoming appointments.");
                    Optional<ButtonType> result = reminder.showAndWait();
                } else {
                    // getting upcoming Appointments needed for 15 minute alert
                    for (Appointment a : upcomingAppointments) {
                        Alert reminder = new Alert(Alert.AlertType.INFORMATION, "Appointment ID: " + a.getAppointmentID() +
                                " starting in 15 mins! \n\n" + a.getStart().format(dtf) + " " + currentTimeZone.getZone());
                        Optional<ButtonType> result = reminder.showAndWait();
                    }

                }
                stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
                scene = FXMLLoader.load(getClass().getResource("/view/customerMenu.fxml"));
                stage.setScene(new Scene(scene));
                stage.show();
                return;
            }

        }
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
        PrintWriter writer = new PrintWriter(new FileWriter("login_activity.txt", true));
        writer.append(LocalDateTime.now(UTC).format(dtf) + " | " + userNameTxt.getText() + " | fail\n");
        writer.flush();
        writer.close();

            Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "log-in not valid pls try again");

            Optional<ButtonType> result = alert.showAndWait();


    }












    /**This is the initialize method. This method initializes the labels with data.*/
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        zoneIdLbl.setText(ZoneId.systemDefault().toString());

        userNameLbl.setText(rb.getString("userName"));
        passwordLbl.setText(rb.getString("password"));
    }
}




