package controller;

import helper.customersByCountry;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import utilities.CustomerCRUD;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

/**This is the customers by country class.*/
public class customersByCountryController implements Initializable {


    Stage stage;
    Parent scene;

    @FXML
    private Button exitBtn;

    @FXML
    private TableView<customersByCountry> customersByDivision_IdTable;

    @FXML
    private TableColumn<customersByCountry, String> nameCol;

    @FXML
    private TableColumn<customersByCountry, String> countryCol;


    /**This is the exit button method. This method switches screens to the report's menu page.*/
    @FXML
    void onActionExit(ActionEvent event) throws IOException {

        stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/view/reportsMenu.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();

    }

    /**This is the initialize method. This method initializes the table with data.*/
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        try {
            customersByDivision_IdTable.setItems(CustomerCRUD.getCustomersByDivisionId());
            nameCol.setCellValueFactory(new PropertyValueFactory<>("Name"));
            countryCol.setCellValueFactory(new PropertyValueFactory<>("CountryName"));
        } catch (SQLException e) {
            e.printStackTrace();
        }




    }
}
