package controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

import java.io.IOException;

/**This is the appointment's menu class*/
public class appointmentsMenu {

    Stage stage;
    Parent scene;

    @FXML
    private Button exit;

    @FXML
    private Button save;

    /**This is the exit button method. This method switches screens to the customer menu page.*/
    @FXML
    void onActionExit(ActionEvent event) throws IOException {

        stage = (Stage)((Button)event.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/view/customerMenu.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();

    }


    @FXML
    void onActionSave(ActionEvent event) throws IOException {

        stage = (Stage)((Button)event.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/view/customerMenu.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();

    }


}
