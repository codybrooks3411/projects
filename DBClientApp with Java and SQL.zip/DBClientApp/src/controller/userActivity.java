package controller;

import helper.UserActivity;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

/**This is the user activity class.*/
public class userActivity implements Initializable {

    Stage stage;
    Parent scene;

    @FXML
    private TableView<UserActivity> userActivityTable;

    @FXML
    private TableColumn<UserActivity, String> userNameCol;

    @FXML
    private TableColumn<UserActivity, String> dateCol;

    @FXML
    private TableColumn<UserActivity, String> timeCol;

    @FXML
    private TableColumn<UserActivity, Boolean> successfullOrNotCol;

    @FXML
    private Button exitBtn;

    /**This is the exit button method. This method switches screens to the customer menu page.*/
    @FXML
    void onActionExit(ActionEvent event) throws IOException {

        stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/view/customerMenu.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();

    }

    /**This is the initialize method. This method initializes the table with data.*/
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        userActivityTable.setItems(UserActivity.getUserActivityRecords());
        userNameCol.setCellValueFactory(new PropertyValueFactory<>("userName"));
        dateCol.setCellValueFactory(new PropertyValueFactory<>("date"));
        timeCol.setCellValueFactory(new PropertyValueFactory<>("time"));
        successfullOrNotCol.setCellValueFactory(new PropertyValueFactory<>("successfullOrNot"));

    }
}
