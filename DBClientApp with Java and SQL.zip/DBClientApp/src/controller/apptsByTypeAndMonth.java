package controller;

import helper.gettingApptByMonthAndType;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import model.Appointment;
import model.Contact;
import utilities.AppointmentCRUD;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;


/**This is the appointments by type and month class.*/
public class apptsByTypeAndMonth implements Initializable {

    Stage stage;
    Parent scene;

    @FXML
    private TableView<gettingApptByMonthAndType> apptsByTypeAndMonthTable;

    @FXML
    private TableColumn<Appointment, String> typeCol;

    @FXML
    private TableColumn<Appointment, String> monthCol;

    @FXML
    private TableColumn<Appointment, Integer> totalApptsCol;

    @FXML
    private Button exitBtn;


    /**This is the exit button method. This method switches screens to the report's menu page.*/
    @FXML
    void onActionExit(ActionEvent event) throws IOException {
        stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/view/reportsMenu.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();

    }


    /**This is the initialize method. This method initializes the table with data.*/
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        apptsByTypeAndMonthTable.setItems(AppointmentCRUD.getAppointmentsByMonthAndType());
        typeCol.setCellValueFactory(new PropertyValueFactory<>("Type"));
        monthCol.setCellValueFactory(new PropertyValueFactory<>("Month"));
        totalApptsCol.setCellValueFactory(new PropertyValueFactory<>("totalAppointments"));
    }
}
