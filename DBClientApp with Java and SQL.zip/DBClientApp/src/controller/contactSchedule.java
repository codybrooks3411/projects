package controller;

import helper.ListManager;
import helper.StageGetter;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import model.Contact;
import utilities.AppointmentCRUD;
import utilities.ContactCRUD;

import java.io.IOException;
import java.net.URL;
import java.time.LocalDateTime;
import java.util.ResourceBundle;

/**This is the contact schedule class.*/
public class contactSchedule implements Initializable {

    Stage stage;
    Parent scene;

    @FXML
    private TableView<contactSchedule> contactScheduleTable;

    @FXML
    private TableColumn<Contact, Integer> apptIdCol;

    @FXML
    private TableColumn<Contact, Integer> customerIdCol;

    @FXML
    private TableColumn<Contact, String> typeCol;

    @FXML
    private TableColumn<Contact, String> descriptionCol;

    @FXML
    private TableColumn<Contact, LocalDateTime> startCol;

    @FXML
    private TableColumn<Contact, LocalDateTime> endCol;

    @FXML
    private TableColumn<Contact, String> titleCol;

    @FXML
    private Button exitBtn;

    /**This is 1 of 2 lambdas used. This lambda switches screens to the report's menu.*/
    public StageGetter myGetter = e -> {
        return (Stage) ((Button) e.getSource()).getScene().getWindow();
    };

    @FXML
    void onActionExit(ActionEvent event) throws IOException {

        stage = myGetter.getStage(event);
        scene = FXMLLoader.load(getClass().getResource("/view/reportsMenu.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();

    }

    /**This is the initialize method. This method initializes the combo box with a list of contacts and populates
     * the table.*/
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        contactsCb.setItems(ListManager.allContacts);

        contactScheduleTable.setItems(AppointmentCRUD.getAllContactSchedules());
        apptIdCol.setCellValueFactory(new PropertyValueFactory<>("appointmentId"));
        customerIdCol.setCellValueFactory(new PropertyValueFactory<>("customerId"));
        typeCol.setCellValueFactory(new PropertyValueFactory<>("Type"));
        descriptionCol.setCellValueFactory(new PropertyValueFactory<>("Description"));
        startCol.setCellValueFactory(new PropertyValueFactory<>("Start"));
        endCol.setCellValueFactory(new PropertyValueFactory<>("End"));
        titleCol.setCellValueFactory(new PropertyValueFactory<>("Title"));


    }

    public void onActionContactsCb(ActionEvent actionEvent) {
        int a = contactsCb.getSelectionModel().getSelectedItem().getContactID();

        contactScheduleTable.setItems(ContactCRUD.getContactSchedule(contactsCb.getSelectionModel().getSelectedItem().getContactID()));

    }

    @FXML
    private ComboBox<Contact> contactsCb;

}
