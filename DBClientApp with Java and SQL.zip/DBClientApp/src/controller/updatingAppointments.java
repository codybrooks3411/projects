package controller;

import helper.ListManager;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import model.*;
import utilities.AppointmentCRUD;
import utilities.DivisionCRUD;

import java.awt.*;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.time.*;
import java.util.ArrayList;
import java.util.IllegalFormatException;
import java.util.ResourceBundle;

import static helper.ListManager.*;

/**This is the updating appointments class.*/
public class updatingAppointments implements Initializable {

    Stage stage;
    Parent scene;
    int index;

    @FXML
    private TextField appointmentIDTxt;

    @FXML
    private TextField userIDTxt;

    @FXML
    private TextField customerIDTxt;

    @FXML
    private TextField descriptionTxt;

    @FXML
    private TextField locationTxt;

    @FXML
    private TextField typeTxt;


    @FXML
    private TextField startDateAndTimeTxt;

    @FXML
    private TextField endDateAndTimeTxt;

    @FXML
    private Button saveButton;

    @FXML
    private Button cancelButton;

    @FXML
    private DatePicker startDatePicker;

    @FXML
    private DatePicker endDatePicker;

    @FXML
    private ComboBox<LocalTime> startTimeCb;

    @FXML
    private ComboBox<LocalTime> endTimeCb;

    @FXML
    private ComboBox<Contact> contactCb;

    @FXML
    private ComboBox<Integer> userIdCb;

    @FXML
    private ComboBox<Integer> customerIdCb;

    @FXML
    private TextField titleTxt;

    @FXML
    void onActionContactCb(ActionEvent event) {

    }



    /**This is the end times combo box method. This method populates the combo box with time data. */
    @FXML
    void onActionEndTimeCb(ActionEvent event) {

        endTimeCb.setItems(endTimes);

    }


    /**This is the start times combo box method. This method populates the combo box with time data.*/
    @FXML
    void onActionStartTimeCb(ActionEvent event) {

       // LocalTime startTimeToChoose = startTimeCb.getValue();

        startTimeCb.setItems(startTimes);

    }

    public void onActionUserIdCb(ActionEvent actionEvent) {
    }

    public void onActionCustomerIdCb(ActionEvent actionEvent) {
    }

    /**This is the cancel button method. This method switches screens to the customer menu page.*/
    @FXML
    void onActionCancel(ActionEvent event) throws IOException {

        stage = (Stage)((Button)event.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/view/customerMenu.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();

    }

    /**This is the save button method. This method saves the inputted data and switches screens to the
     * customer menu page.*/
    @FXML
    void onActionSave(ActionEvent event) throws IOException {

        try {
            int appointmentID = Integer.parseInt(appointmentIDTxt.getText());
            int customerID = customerIdCb.getValue();
            String Title = titleTxt.getText();
            String Description = descriptionTxt.getText();
            String Location = locationTxt.getText();
            String Type = typeTxt.getText();
            int contactId = contactCb.getValue().getContactID();
            int userID = userIdCb.getValue();
            LocalTime Start = startTimeCb.getValue();
            LocalTime End = endTimeCb.getValue();
            LocalDate date = startDatePicker.getValue();
            LocalDateTime startDateTime = LocalDateTime.of(date, Start);
            LocalDateTime endDateTime = LocalDateTime.of(date, End);

            AppointmentCRUD.update(appointmentID, Title, Description, Location, Type,
                    startDateTime, endDateTime, customerID, userID, contactId);

            stage = (Stage)((Button)event.getSource()).getScene().getWindow();
            scene = FXMLLoader.load(getClass().getResource("/view/customerMenu.fxml"));
            stage.setScene(new Scene(scene));
            stage.show();

        }

        catch (IllegalFormatException e) {

            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error Dialog");
            alert.setContentText("Need to type appropriate text.");
            alert.showAndWait();

        }
        catch (SQLException e) {
            e.printStackTrace();
        }
        /*catch (SQLException e) {
            e.printStackTrace();
        }

        catch (IllegalFormatException e) {

            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error Dialog");
            alert.setContentText("Need to type appropriate text.");
            alert.showAndWait();

        }
        catch (NumberFormatException e) {
            e.printStackTrace();

            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error Dialog");
            alert.setContentText("Need to type appropriate text.");
            alert.showAndWait();

        }*/




    }

    /**This is the initialize method. This method initializes the combo box to a list of all contacts and
     * disables the appointment id text field.*/
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        appointmentIDTxt.setDisable(true);
        contactCb.setItems(allContacts);

        ObservableList<Integer> list = FXCollections.observableArrayList();
        allUsers.forEach(user -> {
            list.add(user.getUserID());

        });

        userIdCb.setItems(list);

        ObservableList<Integer> contactList = FXCollections.observableArrayList();
        allCustomers.forEach(customer -> {
            contactList.add(customer.getCustomerID());

        });

        customerIdCb.setItems(contactList);

    }

    /**This is the send appointment method. This method sends appointment data to be updated.*/
    public void sendAppointment(Appointment appointment, int index) {
        this.index = index;
        appointmentIDTxt.setText((String.valueOf(appointment.getAppointmentID())));
        userIdCb.setValue(appointment.getUserID());
        customerIdCb.setValue(appointment.getCustomerID());
        descriptionTxt.setText((String.valueOf(appointment.getDescription())));
        locationTxt.setText((String.valueOf(appointment.getLocation())));
        typeTxt.setText((String.valueOf(appointment.getType())));
        titleTxt.setText((String.valueOf(appointment.getTitle())));
        startDatePicker.setValue(appointment.getStart().toLocalDate());
        endDatePicker.setValue(appointment.getEnd().toLocalDate());
        startTimeCb.setValue(appointment.getStart().toLocalTime());
        endTimeCb.setValue(appointment.getEnd().toLocalTime());


        LocalDateTime ldt = LocalDateTime.of(LocalDate.now(), LocalTime.of(8, 0));
        ZoneId estZid = ZoneId.of("America/New_York");

        ZonedDateTime estZdt = ZonedDateTime.of(ldt, estZid);

        ZoneId localZid = ZoneId.systemDefault();

        ZonedDateTime localZdt = ZonedDateTime.ofInstant(estZdt.toInstant(), localZid);
        // System.out.println(localZdt);


        for(int i = localZdt.getHour(); i < localZdt.getHour() + 14; i++) {
            ListManager.startTimes.add(LocalTime.from(LocalTime.of(i, 0)));
        }

        for(int i = localZdt.getHour(); i < localZdt.getHour() + 14; i++) {
            ListManager.endTimes.add(LocalTime.from(LocalTime.of(i, 0)));
        }

        startTimeCb.setItems(startTimes);
        endTimeCb.setItems(endTimes);

        ZoneId utcZoneId = ZoneId.of("UTC");
        ZonedDateTime utcZDT = ZonedDateTime.ofInstant(estZdt.toInstant(), utcZoneId);
        estZdt = ZonedDateTime.ofInstant(utcZDT.toInstant(), localZid);

      /*  LocalTime start = LocalTime.of(8, 0);
        LocalTime end = LocalTime.of(22,0);

        while(start.isBefore(end.plusSeconds(1))) {

            startTimeCb.getItems().add(start);
            start = start.plusMinutes(10);

            startTimeCb.getSelectionModel().select(LocalTime.of(get));

        }*/

        for(Contact c : allContacts) {

           if(c.getContactID() == appointment.getContactId()) {
               contactCb.setValue(c);

            }


        }
    }
}



