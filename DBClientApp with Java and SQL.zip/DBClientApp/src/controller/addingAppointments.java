package controller;

import helper.ListManager;
import helper.contactScheduleHelper;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import model.*;
import utilities.AppointmentCRUD;
import utilities.ContactCRUD;
import utilities.DivisionCRUD;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.*;
import java.time.chrono.ChronoLocalDate;
import java.time.chrono.ChronoLocalDateTime;
import java.util.IllegalFormatException;
import java.util.ResourceBundle;

import static helper.ListManager.*;
import static java.time.ZoneOffset.UTC;

/**This is the adding appointments class.*/
public class addingAppointments implements Initializable {

    Stage stage;
    Parent scene;


    @FXML
    private TextField appointmentIDTxt;

    @FXML
    private TextField userIDTxt;

    @FXML
    private TextField customerIDTxt;

    @FXML
    private TextField descriptionTxt;

    @FXML
    private TextField locationTxt;

    @FXML
    private TextField typeTxt;

    @FXML
    private TextField startDateAndTimeTxt;

    @FXML
    private TextField endDateAndTimeTxt;

    @FXML
    private TextField titleTxt;

    @FXML
    private ComboBox<Contact> contactCb;


    @FXML
    private Button saveButton;

    @FXML
    private Button cancelButton;


    @FXML
    private DatePicker startDatePicker;

    @FXML
    private DatePicker endDatePicker;

    @FXML
    private ComboBox<LocalTime> startTimeCb;

    @FXML
    private ComboBox<LocalTime> endTimeCb;

    @FXML
    private ComboBox<User> userIdCb;

    @FXML
    private ComboBox<Customer> customerIdCb;

    @FXML
    void onActionCustomerIdCb(ActionEvent event) {

    }


    @FXML
    void onActionUserIdCb(ActionEvent event) {

    }

    @FXML
    void onActionContactCb(ActionEvent event) {


    }


    @FXML
    void onActionEndTimeCb(ActionEvent event) {


    }


    @FXML
    void onActionStartTimeCb(ActionEvent event) {

    }

    /**This is the cancel button method. This method switches screens to the customer menu.*/
    @FXML
    void onActionCancel(ActionEvent event) throws IOException {
        stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/view/customerMenu.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();

    }

    /**This is the save button method. This method saves the inputted data for adding an appointment.*/
    @FXML
    void onActionSave(ActionEvent event) throws IOException {

        try {

            int userId = Integer.parseInt(String.valueOf(userIdCb.getSelectionModel().getSelectedItem()));
            int customerId = Integer.parseInt(String.valueOf(customerIdCb.getSelectionModel().getSelectedItem()));
            String title = titleTxt.getText();
            String description = descriptionTxt.getText();
            String location = locationTxt.getText();
            String type = typeTxt.getText();
            int contact = contactCb.getSelectionModel().getSelectedItem().getContactID();

            LocalTime Start = startTimeCb.getValue();
            LocalTime End = endTimeCb.getValue();
            LocalDate date = startDatePicker.getValue();
            LocalDateTime start = LocalDateTime.of(date, Start);
            LocalDateTime end = LocalDateTime.of(date, End);

          /*  for(Contact c : allContacts) {

                if(c.getContactID() == appointment.getContactId()) {
                    contactCb.setValue(c);

                }


        } */

        
        
    


           // LocalDateTime start = LocalDateTime.parse(String.valueOf(startTimeCb.getSelectionModel().getSelectedItem()));
           // LocalDateTime end = LocalDateTime.parse(String.valueOf(endTimeCb.getSelectionModel().getSelectedItem()));

            LocalDateTime ldt = LocalDateTime.of(LocalDate.now(), LocalTime.of(8, 0));


            ZoneId estZid = ZoneId.of("America/New_York");

            LocalTime ltClose = LocalTime.of(22,0,0);

            ZonedDateTime estZdt = ZonedDateTime.of(ldt, estZid);

            ZoneId localZid = ZoneId.systemDefault();

            ZonedDateTime localZdt = ZonedDateTime.ofInstant(estZdt.toInstant(), localZid);
            // System.out.println(localZdt);


            for(int i = localZdt.getHour(); i < localZdt.getHour() + 14; i++) {
                startTimes.add(i, LocalTime.ofSecondOfDay(0));
            }

            for(int i = localZdt.getHour(); i < localZdt.getHour() + 14; i++) {
                endTimes.add(i, LocalTime.ofSecondOfDay(0));
            }

            // Date
            LocalDate startDateSelection = startDatePicker.getValue();
            LocalDate endDateSelection = endDatePicker.getValue();

            // Start Date
            LocalTime startTime = startTimeCb.getValue();
            LocalDateTime startDateTime = LocalDateTime.of(startDateSelection, startTime);
            ZonedDateTime startUTC = ZonedDateTime.of(startDateTime, UTC);
            LocalDateTime finalStart = startUTC.toLocalDateTime();

            // End Date
            LocalTime endTime = endTimeCb.getValue();
            LocalDateTime endDateTime = LocalDateTime.of(startDateSelection, endTime);
            ZonedDateTime endUTC = ZonedDateTime.of(endDateTime, UTC);
            LocalDateTime finalEnd = endUTC.toLocalDateTime();

            LocalDateTime createDate = LocalDateTime.now();
            String createdBy = User.currentUser;
            LocalDateTime lastUpdate = LocalDateTime.now();
            String lastUpdatedBy = User.currentUser;

            ZoneId utcZoneId = ZoneId.of("UTC");
            ZonedDateTime utcZDT = ZonedDateTime.ofInstant(estZdt.toInstant(), utcZoneId);
            estZdt = ZonedDateTime.ofInstant(utcZDT.toInstant(), localZid);

            // convert appointment time selections to current user time zone
            ZonedDateTime zdtStart = ZonedDateTime.of(startDateTime, ZoneId.systemDefault());
            ZonedDateTime zdtEnd = ZonedDateTime.of(endDateTime, ZoneId.systemDefault());

            // assign converted appointment times to ldt for evaluation of EST business hours
            LocalDateTime ldtOpen = LocalDateTime.of(LocalDate.from(zdtStart), LocalTime.from(ldt));
            LocalDateTime ldtClose = LocalDateTime.of(LocalDate.from(zdtEnd), ltClose);

            ZonedDateTime open = ZonedDateTime.of(ldtOpen, estZid);
            ZonedDateTime close = ZonedDateTime.of(ldtClose, estZid);






            // overlapping appointments
            for (Appointment a : ListManager.allAppointments) {
                if (a.getCustomerID() == customerId) {
                    if (a.getStart().isBefore(ChronoLocalDateTime.from(startDateTime)) && a.getEnd().isAfter(ChronoLocalDateTime.from(endDateTime)) ||
                            a.getStart().isEqual(ChronoLocalDateTime.from(startDateTime)) ||
                            a.getEnd().isEqual(ChronoLocalDateTime.from(endDateTime))) {
                        Alert timingError = new Alert(Alert.AlertType.ERROR);
                        timingError.setTitle("Timing Error");
                        timingError.setContentText("Appointments are overlapping.");
                        timingError.showAndWait();
                        return;
                    } else if (a.getStart().isBefore(ChronoLocalDateTime.from(startDateTime)) && a.getEnd().isAfter(ChronoLocalDateTime.from(startDateTime)) ||
                            a.getStart().isBefore(ChronoLocalDateTime.from(end))
                                    && a.getEnd().isAfter(ChronoLocalDateTime.from(end))) {
                        Alert timingError = new Alert(Alert.AlertType.ERROR);
                        timingError.setTitle("Timing Error");
                        timingError.setContentText("Appointments are overlapping.");
                        timingError.showAndWait();
                        return;
                    } else if (a.getStart().isAfter(ChronoLocalDateTime.from(startDateTime)) && a.getEnd().isBefore(ChronoLocalDateTime.from(endDateTime))) {
                        Alert timingError = new Alert(Alert.AlertType.ERROR);
                        timingError.setTitle("Timing Error");
                        timingError.setContentText("Appointments are overlapping.");
                        timingError.showAndWait();
                        return;
                    }
                }
            }

            if (titleTxt == null || descriptionTxt == null || locationTxt == null || typeTxt == null) {
                Alert missingInfo = new Alert(Alert.AlertType.ERROR);
                missingInfo.setTitle("Format Error");
                missingInfo.setContentText("Unable to save appointment.");
                missingInfo.showAndWait();
            }
            else if (start.isAfter(LocalDateTime.from(endDateTime))) {
                Alert timeError = new Alert(Alert.AlertType.ERROR);
                timeError.setTitle("Format Error");
                timeError.setContentText("confirm that your Start time is correct.");
                timeError.showAndWait();
            }
            else if (start.isBefore(LocalDateTime.now())) {
                Alert dateError = new Alert(Alert.AlertType.ERROR);
                dateError.setTitle("Format Error");
                dateError.setContentText("The Start Time cannot be in the past.");
                dateError.showAndWait();
            }
            // business hour validation (8am - 10pm including weekends)
            else if (zdtStart.isBefore(open) || zdtEnd.isAfter(close)) {
                Alert timingError = new Alert(Alert.AlertType.ERROR);
                timingError.setTitle("Timing Error");
                timingError.setContentText("Appt time must be during business hours 8:00 - 22:00 EST");
                timingError.showAndWait();
            }
            else {
                AppointmentCRUD.insert(customerId, userId, title, description,
                        location, contact, type, start, end);
            }


            stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
            scene = FXMLLoader.load(getClass().getResource("/view/customerMenu.fxml"));
            stage.setScene(new Scene(scene));
            stage.show();


        }
        catch (IllegalFormatException e) {

            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error Dialog");
            alert.setContentText("Need to type appropriate text.");
            alert.showAndWait();

        }
        catch (SQLException e) {
            e.printStackTrace();
        }

    }


    /**This is the initialize method. This method initializes the combo boxes and text fields. */
        @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

       /* ObservableList<Integer> hourTimes = FXCollections.observableArrayList();

        for (int i = 0; i <= 23; i++) {
            hourTimes.add(i);
        }*/


            LocalDateTime ldt = LocalDateTime.of(LocalDate.now(), LocalTime.of(8, 0));
            ZoneId estZid = ZoneId.of("America/New_York");

            ZonedDateTime estZdt = ZonedDateTime.of(ldt, estZid);

            ZoneId localZid = ZoneId.systemDefault();

            ZonedDateTime localZdt = ZonedDateTime.ofInstant(estZdt.toInstant(), localZid);
            // System.out.println(localZdt);


            for(int i = localZdt.getHour(); i < localZdt.getHour() + 14; i++) {
                ListManager.startTimes.add(LocalTime.from(LocalTime.of(i, 0)));
            }

            for(int i = localZdt.getHour(); i < localZdt.getHour() + 14; i++) {
                ListManager.endTimes.add(LocalTime.from(LocalTime.of(i, 0)));
            }

        startTimeCb.setItems(startTimes);
        endTimeCb.setItems(endTimes);
        appointmentIDTxt.setDisable(true);
        userIdCb.setItems(allUsers);
        customerIdCb.setItems(allCustomers);
        contactCb.setItems(allContacts);


    }
}

