package controller;

import helper.ListManager;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import model.Country;
import model.Customer;
import model.Division;
import utilities.CountryCRUD;
import utilities.CustomerCRUD;
import utilities.DivisionCRUD;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.IllegalFormatException;
import java.util.ResourceBundle;

import static helper.ListManager.*;

/**This is the updating customers class.*/
public class updatingCustomers implements Initializable {

    Stage stage;
    Parent scene;
    Customer customer;
    int index;

    @FXML
    private TextField customerIDTxt;

    @FXML
    private TextField addressTxt;

    @FXML
    private TextField postalCodeTxt;

    @FXML
    private TextField customerNameTxt;

    @FXML
    private TextField phoneNumberTxt;

    @FXML
    private Button exit;

    @FXML
    private Button save;

    @FXML
    private ComboBox<Country> countryCb;

    @FXML
    private ComboBox<Division> fldCb;

    /**This is the country combo box method. This method populates the country and first-level division
     * combo boxes with data.*/
    @FXML
    void onActionCountryCb(ActionEvent event) throws SQLException {

        Country countriesToChoose = countryCb.getValue();

        fldCb.setItems(DivisionCRUD.getDivisionsByCountry(countriesToChoose.getCountryID()));

    }

    @FXML
    void OnActionFldCb(ActionEvent event) {

    }



    /**This is the exit button method. This method switches screens to the customer menu page.*/
    @FXML
    void onActionExit(ActionEvent event) throws IOException {
        stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        scene = FXMLLoader.load(getClass().getResource("/view/customerMenu.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();

    }

    /**This is the send customer method. This method sends customer data to be updated.*/
    public void sendCustomer(Customer customer, int index) throws SQLException {

        countryCb.setItems(allCountries);

        this.index = index;
        customerIDTxt.setText(String.valueOf(customer.getCustomerID()));
        addressTxt.setText(String.valueOf(customer.getAddress()));
        postalCodeTxt.setText(String.valueOf(customer.getPostalCode()));
        customerNameTxt.setText(String.valueOf(customer.getCustomerName()));
        phoneNumberTxt.setText(String.valueOf(customer.getPhone()));
        /* ListManager.allCountries.forEach(country -> {
            if(country.getCountryID()== customer.getCountryID()) {
                countryCb.setValue(country);
            }
        }); */

        //fldCb.setValue(customer.getDivisionID());

        for(Country c : allCountries) {

            if(c.getCountryID() == customer.getCountryID()) {

                countryCb.setValue(c);
                fldCb.setItems(DivisionCRUD.getDivisionsByCountry(c.getCountryID()));

            }

        }

        for(Division d : allDivisions) {

            if(d.getDivisionID() == customer.getDivisionID()) {
                fldCb.setValue(d);
            }

        }



    }


    /**This is the save button method. This method saves the inputted data and switches screens to the
     * customer menu page.*/
    @FXML
    void onActionSave(ActionEvent event) throws IOException {

        try {
            String customerName = customerNameTxt.getText();
            String address = addressTxt.getText();
            String postalCode = (postalCodeTxt.getText());
            String phone = (phoneNumberTxt.getText());
            int divisionId = fldCb.getValue().getDivisionID();
            int customerId = Integer.parseInt(customerIDTxt.getText());
            //int countryId = countryCb.getSelectionModel().getSelectedItem().getCountryID();
            int countryId = countryCb.getValue().getCountryID();

            CustomerCRUD.update(customerName, divisionId, address,
                    phone, postalCode, customerId);


            stage = (Stage)((Button)event.getSource()).getScene().getWindow();
            scene = FXMLLoader.load(getClass().getResource("/view/customerMenu.fxml"));
            stage.setScene(new Scene(scene));
            stage.show();
        }

       /* catch (NumberFormatException e) {

            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error Dialog");
            alert.setContentText("Enter a numeric value for zip cope and phone number.");
            alert.showAndWait();

        }*/ catch (IllegalFormatException e) {

            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error Dialog");
            alert.setContentText("Need to type appropriate text.");
            alert.showAndWait();

        }
        catch (SQLException e) {
            e.printStackTrace();
        }

    }

    /**This is the initialize method. This method initializes the combo box and disables the
     * customer id txt field*/
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        countryCb.setItems(allCountries);




        fldCb.setPromptText("need to choose a country 1st");

        customerIDTxt.setDisable(true);

    }
}



