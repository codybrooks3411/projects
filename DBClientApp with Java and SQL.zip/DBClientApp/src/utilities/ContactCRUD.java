package utilities;

import controller.contactSchedule;
import helper.JDBC;
import helper.ListManager;
import helper.contactScheduleHelper;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.Contact;

import java.sql.*;
import java.time.LocalDateTime;

/**This is the contact crud class.*/
public class ContactCRUD {

    /**This is the select method. This method selects contacts.*/
    public static void select() throws SQLException {
        String sql = "SELECT * FROM contacts";
        PreparedStatement ps = JDBC.connection.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();
        while(rs.next()) {
            int contactID = rs.getInt("Contact_ID");
            String email = rs.getString("Email");
            String contactName = rs.getString("Contact_Name");
            ListManager.allContacts.add(new Contact(contactName, email, contactID));


        }
    }

    /**This is the update contact schedule method. This method updates the contacts schedule with data.*/
    public static int updateContactSched(int appointment_ID, int Customer_ID, String Type, String Description,
                                         LocalDateTime Start, LocalDateTime End, String Title) throws SQLException {

        String sql = "UPDATE Contact SET appointment_ID = ?, Customer_ID = ?, Type = ?, Description = ?," +
                " Start = ?, End = ?, Title = ? WHERE Contact_ID = ?";

        PreparedStatement ps = JDBC.connection.prepareStatement(sql);

        ps.setInt(1, appointment_ID);
        ps.setInt(2, Customer_ID);
        ps.setString(3, Type);
        ps.setString(4, Description);
        ps.setTimestamp(5, Timestamp.valueOf(Start));
        ps.setTimestamp(6, Timestamp.valueOf(End));
        ps.setString(7, Title);

        int rowsAffected = ps.executeUpdate();
        return rowsAffected;

    }

    /**This is the get contact schedule method. This method gets the contacts schedule data.*/
    public static ObservableList<contactSchedule> getContactSchedule(int selectedContactID) {
        ObservableList<contactSchedule> contactSchedule = FXCollections.observableArrayList();
        try {
            String sql = "SELECT * from appointments WHERE contact_Id = ?";
            PreparedStatement ps = JDBC.connection.prepareStatement(sql);
            ps.setInt(1, selectedContactID);
            System.out.println(ps.toString());
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                int Contact_ID = rs.getInt("Contact_ID");
                int appointment_ID = rs.getInt("Appointment_ID");
                String title = rs.getString("Title");
                String type = rs.getString("Type");
                String description = rs.getString("Description");
                LocalDateTime start = rs.getTimestamp("Start").toLocalDateTime();
                LocalDateTime end = rs.getTimestamp("End").toLocalDateTime();
                int customerId = rs.getInt("Customer_ID");
                contactScheduleHelper c = new contactScheduleHelper(Contact_ID, appointment_ID, title, type, description,
                        start, end, customerId);
                contactSchedule.add(c);

            }
        }



        catch (SQLException e) {
            e.printStackTrace();
        }
        return contactSchedule;
    }

}
