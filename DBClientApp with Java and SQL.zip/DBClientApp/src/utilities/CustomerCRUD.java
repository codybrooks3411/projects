package utilities;

import helper.JDBC;
import helper.ListManager;
import helper.customersByCountry;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.Customer;

import java.sql.*;

/**This is the customer crud class.*/
public abstract class CustomerCRUD {


    /**This is the get customers by division id method. This method gets customers by division id.*/
    public  static ObservableList<customersByCountry> getCustomersByDivisionId() throws SQLException {
        ObservableList<customersByCountry> list = FXCollections.observableArrayList();

        String sql = "SELECT Customer_Name, customers.Division_Id, Country FROM customers, first_level_divisions," +
                " countries where customers.Division_ID = first_level_divisions.Division_ID AND first_level_divisions.COUNTRY_ID = countries.Country_ID";
        PreparedStatement ps = JDBC.connection.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();
        while (rs.next()) {

            String name = rs.getString("Customer_Name");
            int divisionId = rs.getInt("Division_Id");
            String countryName = rs.getString("Country");
            list.add(new customersByCountry(name, divisionId, countryName));

        }


        return list;
    }



    /**This is the select method. This method selects customers.*/
    public static void select() throws SQLException {
        ListManager.allCustomers.clear();
        String sql = "SELECT customers.*, countries.Country_ID FROM customers, first_level_divisions, countries" +
                " WHERE customers.Division_ID = first_level_divisions.Division_ID AND" +
                " first_level_divisions.Country_ID = countries.Country_ID ";
        PreparedStatement ps = JDBC.connection.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();
        while (rs.next()) {

            int customerID = rs.getInt("Customer_ID");
            int countryId = rs.getInt("Country_ID");
            String customerName = rs.getString("Customer_Name");
            String address = rs.getString("Address");
            String postalCode = rs.getString("Postal_Code");
            String phone = rs.getString("Phone");
            int divisionID = rs.getInt("Division_ID");
            ListManager.allCustomers.add(new Customer(customerID, countryId, divisionID, postalCode, customerName,
                    address, phone));
        }
    }

    /**This is the insert method. This method inserts data for customers.*/
    public static int insert(String customer_Name, String address, String postal_Code,
                             String phone, int division_ID) throws SQLException {

        String sql = "INSERT INTO customers (Customer_Name, Address, Postal_Code, Phone," +
                " Create_Date, Created_By, Last_Update, Last_Updated_By, Division_ID)" +
                " VALUES(?, ?, ?, ?, now(), ?, now(), ?, ?)";
        PreparedStatement ps = JDBC.connection.prepareStatement(sql);

        ps.setString(1, customer_Name);
        ps.setString(2, address);
        ps.setString(3, postal_Code);
        ps.setString(4, phone);
        ps.setString(5, "createdBy");
        ps.setString(6, "lastUpdatedBy");
        ps.setInt(7, division_ID);
        int rowsAffected = ps.executeUpdate();
        return rowsAffected;

    }

    /**This is the update method. This method updates customers.*/
    public static int update(String customerName, int divisionId, String address,
                             String phone, String postalCode, int customerId) throws SQLException {

        String sql = "UPDATE CUSTOMERS SET Customer_Name = ?, Division_ID = ?, " +
                "Address = ?, Phone = ?, Postal_Code = ? WHERE Customer_ID = ?";
        PreparedStatement ps = JDBC.connection.prepareStatement(sql);
        ps.setString(1, customerName);
        //ps.setInt(2, countryId);
        ps.setInt(2, divisionId);
        ps.setString(3, address);
        ps.setString(4, phone);
        ps.setString(5, postalCode);
        ps.setInt(6, customerId);
       // System.out.println(ps.toString());
        int rowsAffected = ps.executeUpdate();
        return rowsAffected;
    }

    /**This is the delete method. This method deletes customers.*/
    public static int delete(int Customer_ID) throws SQLException {

        try {

            String sql = "DELETE FROM appointments WHERE Customer_ID = ?";
            PreparedStatement ps = JDBC.connection.prepareStatement(sql);
            ps.setInt(1, Customer_ID);
            int rowsAffected = ps.executeUpdate();

            String sql2 = "DELETE FROM customers WHERE Customer_ID = ?";
            PreparedStatement ps2 = JDBC.connection.prepareStatement(sql2);
            ps2.setInt(1, Customer_ID);
            int rowsAffected2 = ps2.executeUpdate();
            return rowsAffected2;


        } catch (SQLException e) {
            e.printStackTrace();
        }

        return -1;

    }
}













