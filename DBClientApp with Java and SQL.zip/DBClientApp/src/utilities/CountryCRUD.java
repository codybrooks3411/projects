package utilities;

import helper.JDBC;
import helper.ListManager;
import model.Country;
import model.Customer;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**This is the country crud class.*/
public class CountryCRUD {

    /**This is the select method. This method selects countries.*/
    public static void select() throws SQLException {
        String sql = "SELECT * FROM countries";
        PreparedStatement ps = JDBC.connection.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();
        while(rs.next()) {
            int countryId = rs.getInt("Country_ID");
            String country = rs.getString("Country");
            ListManager.allCountries.add(new Country(countryId,country));


        }
    }

}
