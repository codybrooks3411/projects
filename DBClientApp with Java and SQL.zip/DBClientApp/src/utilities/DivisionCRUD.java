package utilities;

import helper.JDBC;
import helper.ListManager;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.Customer;
import model.Division;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**This is the division crud class.*/
public class DivisionCRUD {

    /**This is the select method. This method selects first-level division data.*/
    public static void select() throws SQLException {
        String sql = "SELECT * FROM first_level_divisions";
        PreparedStatement ps = JDBC.connection.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();
        while(rs.next()) {
            int divisionID = rs.getInt("Division_ID");
            String division = rs.getString("Division");
            int countryID = rs.getInt("Country_ID");
            ListManager.allDivisions.add(new Division(division,divisionID,countryID));
        }
    }

    /**This is the get divisions by country method. This method gets first-level division data by country.*/
    public static ObservableList<Division> getDivisionsByCountry(int countryId) throws SQLException {
        ObservableList<Division> list = FXCollections.observableArrayList();
        String sql = "SELECT * FROM first_level_divisions WHERE Country_Id = ?";
        PreparedStatement ps = JDBC.connection.prepareStatement(sql);
        ps.setInt(1, countryId);
        System.out.println(ps);
        ResultSet rs = ps.executeQuery();
        while(rs.next()) {
            int divisionID = rs.getInt("Division_ID");
            String division = rs.getString("Division");
            int countryID = rs.getInt("Country_ID");
            list.add(new Division(division,divisionID,countryID));
        }

        return list;
    }

}
