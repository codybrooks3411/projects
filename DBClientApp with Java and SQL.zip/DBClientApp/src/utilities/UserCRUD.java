package utilities;

import helper.JDBC;
import helper.ListManager;
import model.Customer;
import model.User;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**This is the user crud class.*/
public class UserCRUD {

    /**This is the select method. This method selects users.*/
    public static void select() throws SQLException {
        String sql = "SELECT * FROM users ";
        PreparedStatement ps = JDBC.connection.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();
        while(rs.next()) {
            int user_id = rs.getInt("User_ID");
            String user_Name = rs.getString("User_Name");
            String password = rs.getString("Password");
            ListManager.allUsers.add(new User(user_id, user_Name, password));


        }
    }

}
