package utilities;

import controller.contactSchedule;
import helper.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.Appointment;
import model.Contact;
import model.Customer;

import java.sql.*;
import java.time.LocalDateTime;

/**This is the appointment crud class.*/
public class AppointmentCRUD {



    /**This is the get appointments by month method. This method gets the appointment by each month.*/
    public static ObservableList<gettingApptsByMonth> getAppointmentsByMonth() {

        ObservableList<gettingApptsByMonth> gettingApptsByMonth = FXCollections.observableArrayList();

        try {
            String sql = "SELECT monthName(Start) AS Month FROM appointments " +
                    "GROUP BY Month";
            PreparedStatement ps = JDBC.connection.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                String month = rs.getString("Month");
                gettingApptsByMonth r = new gettingApptsByMonth(month);
                gettingApptsByMonth.add(r);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return gettingApptsByMonth;
    }





    /**This is the get all contacts schedules method. This method gets the contacts schedule.*/
    public static ObservableList<contactSchedule> getAllContactSchedules() {

        ObservableList<contactSchedule> contactScheduleList = FXCollections.observableArrayList();

        try {
            String sql = "SELECT Contact_ID, Appointment_ID, title, type, description, start, end, customer_id FROM" +
                    " client_schedule.appointments ORDER BY start, end";
            PreparedStatement ps = JDBC.connection.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while(rs.next()){
                int contactId = rs.getInt("Contact_ID");
                int appointmentId = rs.getInt("Appointment_ID");
                String title = rs.getString("Title");
                String type = rs.getString("Type");
                String description = rs.getString("Description");
                LocalDateTime start = rs.getTimestamp("Start").toLocalDateTime();
                LocalDateTime end = rs.getTimestamp("End").toLocalDateTime();
                int customerId = rs.getInt("Customer_ID");
                contactScheduleHelper c = new contactScheduleHelper(contactId, appointmentId, title, type, description,
                        start, end, customerId);
                contactScheduleList.add(c);
            }

        } catch (SQLException throwable) {
            throwable.printStackTrace();
        }
        return contactScheduleList;
    }




    /**This is the get appointments by month and type method. This method gets the appointment by month and type.*/
    public static ObservableList<gettingApptByMonthAndType> getAppointmentsByMonthAndType() {

        ObservableList<gettingApptByMonthAndType> gettingApptByMonthAndType = FXCollections.observableArrayList();

        try {
            String sql = "SELECT monthName(Start) AS Month, Type, COUNT(*) AS Total_Appointments FROM appointments " +
                    "GROUP BY Month, Type";
            PreparedStatement ps = JDBC.connection.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                String date = rs.getString("Month");
                String type = rs.getString("Type");
                int totalAppointments = rs.getInt("Total_Appointments");
                gettingApptByMonthAndType r = new gettingApptByMonthAndType(date, type, totalAppointments);
                gettingApptByMonthAndType.add(r);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return gettingApptByMonthAndType;
    }



    /**This is the select method. This method selects appointments.*/
   public static void select() throws SQLException {

       ListManager.allAppointments.clear();
        String sql = "SELECT * FROM appointments";
        PreparedStatement ps = JDBC.connection.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();
        while(rs.next()) {
            String title = rs.getString("title");
            String description = rs.getString("description");
            String location = rs.getString("location");
            String type = rs.getString("type");
            LocalDateTime start = rs.getTimestamp("start").toLocalDateTime();
            LocalDateTime end = rs.getTimestamp("end").toLocalDateTime();
            int appointmentID = rs.getInt("appointment_ID");
            int customerID = rs.getInt("Customer_ID");
            int userID = rs.getInt("User_ID");
            int contactId = rs.getInt("Contact_ID");
            ListManager.allAppointments.add(new Appointment(title, description, location, type, start,
                    end, appointmentID, customerID, userID, contactId));
        }
    }

    /**This is the delete method. This method deletes appointments.*/
    public static int delete(int appointment_ID) throws SQLException {

        String sql = "DELETE FROM APPOINTMENTS WHERE appointment_ID = ?";
        PreparedStatement ps = JDBC.connection.prepareStatement(sql);
        ps.setInt(1, appointment_ID);
        int rowsAffected = ps.executeUpdate();
        return rowsAffected;
    }

    /**This is the update method. This method updates appointments.*/
    public static int update(int Appointment_ID, String Title, String Description, String Location, String Type,
                             LocalDateTime Start, LocalDateTime End, int Customer_ID, int User_ID, int Contact_ID) throws SQLException {

        String sql = "UPDATE APPOINTMENTS SET Title = ?, Description = ?, Location = ?, Type = ?, " +
                "Start = ?, End = ?, Last_Update = ?, " +
                "Last_Updated_By = ?, Customer_ID = ?, User_ID = ?, Contact_ID = ?  WHERE appointment_ID = ?";
        PreparedStatement ps = JDBC.connection.prepareStatement(sql);

        ps.setString(1, Title);
        ps.setString(2, Description);
        ps.setString(3, Location);
        ps.setString(4, Type);
        ps.setTimestamp(5, Timestamp.valueOf(Start));
        ps.setTimestamp(6, Timestamp.valueOf(End));
        ps.setTimestamp(7, Timestamp.valueOf(LocalDateTime.now()));
        ps.setString(8, String.valueOf(User_ID));
        ps.setInt(9, Customer_ID);
        ps.setInt(10, User_ID);
        ps.setInt(11, Contact_ID);
        ps.setInt(12, Appointment_ID);

        int rowsAffected = ps.executeUpdate();
        return rowsAffected;
    }


    /**This is the insert method. This method inserts data for appointments.*/
    public static int insert(int customerId, int userId, String title, String description,
                             String location, int contact, String type, LocalDateTime start, LocalDateTime end)
            throws SQLException {

        String sql = "INSERT INTO appointments (Customer_ID, User_ID, Title, Description, Location, Contact_ID, Type, Start," +
                "End) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?)";
        PreparedStatement ps = JDBC.connection.prepareStatement(sql);
        ps.setInt(1, customerId);
        ps.setInt(2, userId);
        ps.setString(3, title);
        ps.setString(4, description);
        ps.setString(5, location);
        ps.setInt(6, contact);
        ps.setString(7, type);
        ps.setTimestamp(8, Timestamp.valueOf(start));
        ps.setTimestamp(9, Timestamp.valueOf(end));
        int rowsAffected = ps.executeUpdate();
        return rowsAffected;

    }

}
