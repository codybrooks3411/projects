class Truck:
    def __init__(self):
        self.packages = []
        self.mileage = 0
        self.address = "4001 South 700 East"
        self.time = 0
        self.departure = 0

