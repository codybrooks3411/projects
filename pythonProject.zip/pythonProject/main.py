# Cody Brooks 001355588

import csv
import datetime
import math

import package
import truck


# HashTable class using chaining.
class HashTable:
    # Constructor with optional initial capacity parameter.
    # Assigns all buckets with an empty list.
    def __init__(self, initial_capacity=10):
        # initialize the hash table with empty bucket list entries.
        self.table = []
        for i in range(initial_capacity):
            self.table.append([])

    # Inserts a new package into the hash table.
    def insert(self, packages):

        # get the bucket list where package will go.
        bucket = hash(packages.pId) % len(self.table)
        bucket_list = self.table[bucket]

        # insert package to the end of the bucket list.
        bucket_list.append(packages)

    # Searches for a package in the hash table.
    # Returns the item if found, or None if not found.
    def search(self, pId):
        # get the bucket list where package would be.
        bucket = hash(pId) % len(self.table)
        bucket_list = self.table[bucket]

        # search for package in the bucket list
        for packages in bucket_list:
            if packages.pId == pId:
                return packages


hashtable = HashTable()

# Load packages to Hash Table
package.loadPackageData('WGUPSPackageFile.csv', hashtable)

print(hashtable.search(1).address)

for bucket in hashtable.table:
    print("bucket")
    for package in bucket:
        print(package.pId, package.address)


def loadDistanceData(fileName, distances, addresses):
    with open(fileName) as bestPackages:
        packagesData = csv.reader(bestPackages, delimiter=',')
        for line in packagesData:
            # print(repr(distances[0]), repr(distances[1]), distances[2:])
            addresses.append(line[0])
            distances.append(line[2:])


distances = []
addresses = []

# Load distances to Hash Table
loadDistanceData("WGUPSDistanceTable.csv", distances, addresses)


def addressToIndex(address):
    for index, items in enumerate(addresses):
        if address in items:
            return index
    print("error!", address)


def routeAlg(truck):
    while True:
        winnerPackages = None
        winnerDistances = 999999

        for i in truck.packages:
            package = hashtable.search(i)
            if package.deliveryTime:
                continue
            index1 = addressToIndex(truck.address)
            index2 = addressToIndex(package.address)
            if distances[index2][index1] == "":
                distances[index2][index1] = distances[index1][index2]
            # print(i, index1, index2, distances[index2][index1])
            if float(distances[index2][index1]) < winnerDistances:
                winnerPackages = package
                winnerDistances = float(distances[index2][index1])
        # print(winnerDistances, winnerPackages)
        if winnerPackages == None:
            break

        truck.address = winnerPackages.address
        truck.mileage += winnerDistances
        truck.time += datetime.timedelta(hours=winnerDistances / 10)
        winnerPackages.deliveryTime = truck.time
        print("delivered", winnerPackages.pId, winnerPackages.address, str(winnerPackages.deliveryTime),
              winnerPackages.deliveryDeadline)
        winnerPackages.departureTime = truck.departure
        winnerPackages.truckName = truck.name


truck_1 = truck.Truck()
truck_1.departure = truck_1.time = datetime.timedelta(hours=9, minutes=5)
truck_1.name = 1

truck_1.packages = [2, 6, 5, 9, 25, 28, 32, 24, 26, 27, 33, 35, 39]
# print(addressToIndex(truck_1.address))
# print(addressToIndex(hashtable.search(truck_1.packages[0]).address))
# print(distances[0][5])
# print(distances[5][0])
routeAlg(truck_1)

truck_2 = truck.Truck()
truck_2.departure = truck_2.time = datetime.timedelta(hours=9, minutes=5)
truck_2.name = 2

truck_2.packages = [3, 4, 7, 8, 10, 11, 12, 17, 18, 21, 22, 23, 31, 36, 38]

routeAlg(truck_2)

truck_3 = truck.Truck()
truck_3.departure = truck_3.time = datetime.timedelta(hours=8, minutes=0)
truck_3.name = 3

truck_3.packages = [1, 13, 14, 15, 16, 19, 20, 29, 30, 34, 37, 40]

routeAlg(truck_3)

print("total miles: ", truck_1.mileage + truck_2.mileage + truck_3.mileage)

h, m = input("enter a time HH: Min: ").split(":")

user_input_time = datetime.timedelta(hours=int(h), minutes=int(m))
try:
    packageIds = [int(input("enter a package Id or all"))]
except:
    packageIds = range(1, 41)
for packageId in packageIds:
    package = hashtable.search(packageId)
    if user_input_time < package.departureTime:
        package.deliveryStatus = "at the hub"
    elif user_input_time < package.deliveryTime:
        package.deliveryStatus = "in route"
    else:
        package.deliveryStatus = "delivered at %s" % package.deliveryTime

    print("ID:", package.pId, "address:", package.address, "deadline:", package.deliveryDeadline,
          "city:", package.deliveryCity, "zip:", package.deliveryZip, "weight:", package.packageWeight,
          "status:", package.deliveryStatus, "truck", package.truckName)
