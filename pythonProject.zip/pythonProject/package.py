import csv


class Package:
    def __init__(self, pId, address, deliveryDeadline, deliveryCity, deliveryZip, packageWeight, deliveryStatus):
        self.deliveryStatus = deliveryStatus
        self.packageWeight = packageWeight
        self.deliveryZip = deliveryZip
        self.deliveryCity = deliveryCity
        self.deliveryDeadline = deliveryDeadline
        self.address = address
        self.pId = pId
        self.deliveryTime = None
        self.departureTime = None


def loadPackageData(fileName, hashtable):
    with open(fileName) as bestPackages:
        packagesData = csv.reader(bestPackages, delimiter=',')
        next(packagesData)  # skip header
        for packages in packagesData:
            pId = int(packages[0])
            pAddress = packages[1]
            pDeliveryDeadline = packages[5]
            pDeliveryCity = packages[3]
            pDeliveryZip = packages[4]
            pPackageWeight = packages[6]
            pDeliveryStatus = packages[6]

            # package object
            p = Package(pId, pAddress, pDeliveryDeadline, pDeliveryCity, pDeliveryZip, pPackageWeight,
                        pDeliveryStatus)

            # insert it into the hash table
            hashtable.insert(p)

# def loadDistanceData(self, fileName):
#      with open(fileName) as bestDistances:
#        distancesData = csv.reader(bestDistances, delimiter=',')
#        next(distancesData)
#        for distances in distancesData:
